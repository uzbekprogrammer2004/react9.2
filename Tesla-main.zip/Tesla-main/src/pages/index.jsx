import ModelS from "./modelS";
import Model3 from "./model3";
import ModelX from "./modelX";
import ModelY from "./modelY";
import SolarRoof from "./solar-roof";
import SolarPanels from "./solar-panels";

export { ModelS, Model3, ModelX, ModelY, SolarRoof, SolarPanels };