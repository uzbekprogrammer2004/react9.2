import "./style.scss";

const index = () => {
    return (
        <div>
            
        </div>
    );
};

export default index;