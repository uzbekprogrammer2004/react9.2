import "./style.scss";

export default function index({children}) {
  return (
    <main>
      {children}
    </main>
  )
}
